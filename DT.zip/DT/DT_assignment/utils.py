import re
from urllib.parse import urljoin, urlparse
from datetime import datetime

EMAIL_REGEX = r"[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+"
PHONE_REGEX = r"\+?\d[\d\s\-()]{7,}"

def extract_emails(text):
    return list(set(re.findall(EMAIL_REGEX, text)))

def extract_phones(text):
    return list(set(re.findall(PHONE_REGEX, text)))

def clean_text(text):
    return " ".join(text.split())

def is_internal_link(base, link):
    if not link:
        return False
    return urlparse(base).netloc in urlparse(link).netloc

def timestamp():
    return datetime.utcnow().isoformat()
