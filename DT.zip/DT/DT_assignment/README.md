📘 Project README

DT Assignment – Company Website Scraper & Profiling System

1. Project Overview

        This project builds a lightweight web scraping system that extracts structured company information from publicly available websites.
        The goal is to simulate how analysts convert unstructured website content into decision-ready business insights.

The system:

        Accepts a company website URL

        Attempts to extract key business information

        Handles missing or restricted data gracefully

        Produces a structured output suitable for further analysis

2. Objectives

        Extract company-related information from public websites

        Avoid hallucination by relying only on accessible HTML

        Log errors clearly when content is unavailable

        Demonstrate systematic thinking and clean data handling

3. Project Folder Structure
        dt_assignment/
        │
        ├── scraper.py           # Main execution script
        ├── utils.py             # Helper functions for scraping & parsing
        ├── requirements.txt     # Python dependencies
        ├── README.md            # Project documentation
        └── output/              # Sample outputs (optional)

4. Environment Setup

Step 1: Create Virtual Environment (Optional but Recommended)
                python -m venv venv


Activate it:
step1: 
for Windows

        venv\Scripts\activate


for Mac/Linux

        source venv/bin/activate

Step 2: Install Dependencies

Ensure you are inside the project directory:

    pip install -r requirements.txt


Typical dependencies:

        requests
        beautifulsoup4
        lxml

5. How the System Works (High-Level Flow)

a. User provides a website URL

b. Script attempts to fetch HTML content

c. Predefined pages are checked:

        /about

        /products

        /solutions

        /contact

        /careers

d. HTML is parsed for:

        Business description

        Product mentions

        Contact details

        Evidence signals

e. Results are structured into a clean JSON-like output

f. If pages are inaccessible, errors are logged clearly

6. Running the Script

        From the project root directory:

        python scraper.py


When prompted:

        Enter company website URL:


Example:

        https://www.examplecompany.com

7. Output Format

The script returns a structured dictionary containing:

A. Identity

        Website URL

        Company name (if detected)

B. Business Summary

        Auto-generated summary (from visible content)

C. Evidence Signals

        Detected pages

        Keywords related to offerings or domain

        Presence of certifications or products

D. Contact Information

        Emails (if available)

        Phone numbers

        Address

E. Metadata

        Pages successfully crawled

        Pages that failed

        Timestamp of execution

8. Error Handling Logic

        The system is designed to fail safely.

        If a page:

        Is blocked

        Is JavaScript-rendered

        Returns empty HTML

        The system:

        Logs the failure

        Skips the page

        Continues execution

No fake or inferred data is generated.

9. Common Errors & Meaning
Message	Meaning
        "Failed to fetch page"	Page blocked or dynamic
        "No content found"	HTML returned but empty
        "Provide specific URL"	Homepage lacks usable data

10. Limitations

        Cannot extract data from JavaScript-heavy websites without browser automation

        Relies on public HTML only

        Not designed for login-protected pages

11. Future Improvements

        Selenium integration for JS-heavy websites

        Auto-discovery of internal links

        Confidence scoring for extracted signals

        Domain-specific keyword models (e.g., pharma)

12. Summary

        This project demonstrates:

        Structured data extraction

        Clean error handling

        Transparent system behavior

        Practical understanding of real-world web data limitations

        It prioritizes accuracy over assumption, making it suitable for analytical and research workflows.