import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin
from utils import extract_emails, extract_phones, clean_text, is_internal_link, timestamp
from signals import detect_probiotic_signals, score_company

headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36"
}




PRIORITY_PATHS = [
    "/", "/about", "/company", "/products", "/solutions",
    "/industries", "/applications", "/pricing",
    "/contact", "/careers"
]

MAX_PAGES = 12


def fetch_page(url):
    try:
        r: requests.Response=requests.get(url, headers=headers, timeout=10)
        if r.status_code == 200:
            return r.text
        return None
    except Exception:
        return None


def scrape_company(url):
    visited = set()
    pages = []
    errors = []
    full_text = ""

    for path in PRIORITY_PATHS:
        if len(pages) >= MAX_PAGES:
            break

        page_url = urljoin(url, path)
        html = fetch_page(page_url)

        if not html:
            errors.append(f"Failed to fetch {page_url}")
            continue

        soup = BeautifulSoup(html, "lxml")
        text = clean_text(soup.get_text(" ", strip=True))
        full_text += " " + text

        pages.append(page_url)
        visited.add(page_url)

    emails = extract_emails(full_text)
    phones = extract_phones(full_text)

    probiotic_signals = detect_probiotic_signals(full_text)
    score, classification = score_company(probiotic_signals)

    output = {
        "identity": {
            "website": url
        },
        "business_summary": {
            "interpreted_summary": "Auto-generated summary based on visible website text. No assumptions made.",
        },
        "evidence": {
            "pages_detected": pages,
            "probiotic_signals": probiotic_signals
        },
        "contact_location": {
            "emails": emails or ["Not found"],
            "phones": phones or ["Not found"]
        },
        "metadata": {
            "timestamp": timestamp(),
            "pages_crawled": len(pages),
            "errors": errors
        },
        "probiotics_classification": {
            "score": score,
            "classification": classification
        }
    }

    return output

if __name__ == "__main__":
    website = input("Enter company website URL: ").strip()
    result = scrape_company(website)

    from pprint import pprint
    pprint(result)
