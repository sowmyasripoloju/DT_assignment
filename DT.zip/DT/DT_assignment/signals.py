PROBIOTIC_KEYWORDS = [
    "probiotic", "probiotics", "cfu", "lactobacillus",
    "bifidobacterium", "gut health", "microbiome",
    "strain", "fermentation"
]

CERTIFICATIONS = [
    "gmp", "iso", "fssai", "pharma grade"
]

def detect_probiotic_signals(text):
    text = text.lower()
    signals = {
        "keyword_hits": [],
        "certification_hits": []
    }

    for k in PROBIOTIC_KEYWORDS:
        if k in text:
            signals["keyword_hits"].append(k)

    for c in CERTIFICATIONS:
        if c in text:
            signals["certification_hits"].append(c)

    return signals


def score_company(signals):
    score = 0

    if "probiotic" in signals["keyword_hits"]:
        score += 3

    if any(k in signals["keyword_hits"] for k in ["cfu", "strain", "lactobacillus", "bifidobacterium"]):
        score += 2

    if signals["certification_hits"]:
        score += 2

    if len(signals["keyword_hits"]) <= 1:
        score -= 1

    if score >= 5:
        return score, "Probiotics-focused"
    elif score >= 2:
        return score, "Probiotics-adjacent"
    else:
        return score, "Not relevant"
